export interface BusinessProfile {
  name: string;
  description: string;
  address: string;
  website?: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  whatsapp?: string;
  socialMedia?: {
    linkedin?: string;
    facebook?: string;
    instagram?: string;
  };
}

export interface SearchResult {
  businesses: BusinessProfile[];
  summary: string;
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface GemeniResponseData {
  result: SearchResult | null;
  rawText: string;
  groundingChunks: GroundingChunk[];
}

export enum SearchStatus {
  IDLE,
  LOADING,
  PAUSED,
  SUCCESS,
  ERROR
}