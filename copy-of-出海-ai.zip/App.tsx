import React, { useState, useCallback, useRef } from 'react';
import { Search, MapPin, Loader2, Download, AlertCircle, Send, Globe, Mail, Database, StopCircle, Plus, Sparkles, Share2, Copy } from 'lucide-react';
import Header from './components/Header';
import BusinessTable from './components/BusinessTable';
import EmailCampaignModal from './components/EmailCampaignModal';
import { searchBusinesses } from './services/geminiService';
import { POPULAR_COUNTRIES } from './constants';
import { SearchStatus, GemeniResponseData, BusinessProfile } from './types';

const App: React.FC = () => {
  const [keyword, setKeyword] = useState('');
  const [country, setCountry] = useState('United States');
  
  // Core Data State
  const [allBusinesses, setAllBusinesses] = useState<BusinessProfile[]>([]);
  const [selectedIndices, setSelectedIndices] = useState<Set<number>>(new Set());
  
  // Search State
  const [status, setStatus] = useState<SearchStatus>(SearchStatus.IDLE);
  const [error, setError] = useState<string | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  
  // Modal State
  const [showEmailModal, setShowEmailModal] = useState(false);

  // Refs for control
  const shouldStopRef = useRef(false);

  // Deduplication Helper
  const addUniqueBusinesses = (newBusinesses: BusinessProfile[]) => {
    setAllBusinesses(prev => {
      const existingWebsites = new Set(prev.map(b => b.website ? b.website.toLowerCase() : b.name.toLowerCase()));
      const uniqueNew = newBusinesses.filter(b => {
        const key = b.website ? b.website.toLowerCase() : b.name.toLowerCase();
        return !existingWebsites.has(key);
      });
      return [...prev, ...uniqueNew];
    });
  };

  const handleStopSearch = () => {
    shouldStopRef.current = true;
    setStatus(SearchStatus.PAUSED);
  };

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
        alert("链接已复制！请将此链接发送给您的朋友。\nLink copied! Share this URL.");
    });
  };

  const startDeepSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyword.trim()) return;

    // Reset if starting fresh
    if (status === SearchStatus.IDLE || status === SearchStatus.SUCCESS || status === SearchStatus.ERROR) {
        setAllBusinesses([]);
        setLogs([]);
    }
    
    setStatus(SearchStatus.LOADING);
    setError(null);
    shouldStopRef.current = false;
    
    const targetCount = 100;
    let currentCount = 0;
    let round = 0;
    
    // Expanded search strategies to vary the prompts and reach 100 results
    const searchTypes = [
      'top manufacturers and factories', 
      'large scale distributors', 
      'wholesalers and stockists', 
      'importers and trading companies', 
      'niche boutique suppliers',
      'industrial equipment dealers',
      'authorized agents and retailers',
      'direct exporters',
      'local specialized vendors',
      'commercial partners'
    ];

    try {
      while (currentCount < targetCount && !shouldStopRef.current) {
        round++;
        // Cycle through strategies
        const strategyIndex = (round - 1) % searchTypes.length;
        const strategy = searchTypes[strategyIndex];
        
        // Update Log
        setLogs(prev => [`Round ${round}: 正在搜索 ${strategy} ...`, ...prev]);

        // Pass existing names to avoid duplicates in the AI prompt context
        // We snapshot current list
        const currentNames = allBusinesses.map(b => b.name);
        
        // Call Service
        const response = await searchBusinesses(keyword, country, currentNames, strategy);
        
        if (response.result?.businesses && response.result.businesses.length > 0) {
            const newBatch = response.result.businesses;
            addUniqueBusinesses(newBatch);
            
            // Since addUniqueBusinesses is async state update, we roughly track count via newBatch
            currentCount += newBatch.length; 
            
            // Check if we are getting duplicates/diminishing returns
            if (newBatch.length < 2 && round > 8) {
               setLogs(prev => ["结果开始重复，提前结束搜索。", ...prev]);
               break;
            }
        } else {
             setLogs(prev => ["本轮未发现新数据，尝试下一策略...", ...prev]);
        }

        // Rate limiting / Politeness delay (2.5s)
        await new Promise(resolve => setTimeout(resolve, 2500));
        
        // Check if we have enough
        if (currentCount >= targetCount) break;
      }
      
      if (!shouldStopRef.current) {
        setStatus(SearchStatus.SUCCESS);
        setLogs(prev => ["搜索完成！", ...prev]);
      }
    } catch (err) {
      setStatus(SearchStatus.ERROR);
      setError("搜索过程中断或API受限，请稍后重试。");
    }
  };

  const exportToCSV = useCallback(() => {
    if (allBusinesses.length === 0) return;

    const headers = ['Company Name', 'Description', 'Contact Person', 'Address', 'Website', 'Email', 'Phone', 'WhatsApp', 'LinkedIn'];
    const csvContent = [
      headers.join(','),
      ...allBusinesses.map((b: BusinessProfile) => [
        `"${b.name}"`,
        `"${b.description}"`,
        `"${b.contactPerson || ''}"`,
        `"${b.address}"`,
        b.website || '',
        b.email || '',
        b.phone || '',
        b.whatsapp || '',
        b.socialMedia?.linkedin || ''
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `Leads_${keyword}_${country}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [allBusinesses, keyword, country]);

  return (
    <div className="min-h-screen flex flex-col font-sans bg-slate-50 text-gray-900">
      <Header />

      <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Search Section */}
        <div className="bg-white rounded-2xl shadow-xl shadow-brand-900/5 border border-brand-100 p-8 mb-8 transition-all hover:shadow-2xl hover:shadow-brand-900/10">
          <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between mb-8">
            <div>
                <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight flex items-center gap-2">
                   <Sparkles className="w-6 h-6 text-brand-500 fill-brand-100" />
                   外贸获客数据库
                </h2>
                <p className="text-base text-gray-500 mt-2">AI驱动的全球B2B客户深度挖掘引擎</p>
            </div>
            
            {/* Progress Stats */}
            {allBusinesses.length > 0 && (
                <div className="flex items-center gap-6 bg-white px-6 py-3 rounded-2xl shadow-sm border border-gray-100">
                    <div className="text-center">
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Total Leads</p>
                        <p className="text-2xl font-black text-gray-900">{allBusinesses.length}</p>
                    </div>
                    <div className="h-10 w-px bg-gray-100"></div>
                    <div className="text-center">
                        <p className="text-[10px] text-brand-600 font-bold uppercase tracking-wider">Emails</p>
                        <p className="text-2xl font-black text-brand-600">{allBusinesses.filter(b => b.email && b.email !== 'N/A').length}</p>
                    </div>
                     <div className="h-10 w-px bg-gray-100"></div>
                    <div className="text-center">
                        <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider">WhatsApp</p>
                        <p className="text-2xl font-black text-emerald-600">{allBusinesses.filter(b => b.whatsapp && b.whatsapp !== 'N/A').length}</p>
                    </div>
                </div>
            )}
          </div>

          <form onSubmit={startDeepSearch} className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative group">
              <Search className="absolute left-4 top-4 h-5 w-5 text-gray-400 group-focus-within:text-brand-500 transition-colors" />
              <input
                type="text"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                placeholder="输入产品名称或行业 (例如: Solar Panels, LED Lights)"
                className="block w-full pl-12 pr-4 py-4 border border-gray-200 rounded-xl bg-gray-50 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-brand-500 focus:bg-white focus:border-transparent focus:outline-none transition-all text-lg shadow-inner"
              />
            </div>

            <div className="w-full md:w-72 relative group">
              <MapPin className="absolute left-4 top-4 h-5 w-5 text-gray-400 group-focus-within:text-brand-500 transition-colors" />
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="block w-full pl-12 pr-10 py-4 border border-gray-200 rounded-xl bg-gray-50 text-gray-900 focus:ring-2 focus:ring-brand-500 focus:bg-white focus:border-transparent focus:outline-none transition-all appearance-none text-lg shadow-inner cursor-pointer"
              >
                {POPULAR_COUNTRIES.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {status === SearchStatus.LOADING ? (
                <button
                    type="button"
                    onClick={handleStopSearch}
                    className="inline-flex items-center justify-center px-8 py-4 border border-red-200 text-base font-bold rounded-xl shadow-sm text-red-600 bg-red-50 hover:bg-red-100 hover:shadow-md focus:outline-none transition-all min-w-[160px]"
                >
                    <StopCircle className="-ml-1 mr-2 h-5 w-5" />
                    停止搜索
                </button>
            ) : (
                <button
                    type="submit"
                    disabled={!keyword}
                    className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl shadow-lg shadow-brand-500/30 text-white bg-gradient-to-r from-brand-600 to-brand-700 hover:from-brand-500 hover:to-brand-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform active:scale-95 min-w-[160px]"
                >
                    {allBusinesses.length > 0 ? <Plus className="mr-2 h-5 w-5" /> : <Send className="mr-2 h-5 w-5" />}
                    {allBusinesses.length > 0 ? '继续挖掘' : '开始获客'}
                </button>
            )}
          </form>
          
          {/* Search Logs / Status */}
          {status === SearchStatus.LOADING && logs.length > 0 && (
            <div className="mt-4 px-4 py-2 bg-brand-50/50 rounded-lg border border-brand-100 inline-flex items-center gap-3 animate-fade-in">
                <Loader2 className="w-4 h-4 animate-spin text-brand-600" />
                <span className="text-sm text-brand-700 font-medium font-mono">{logs[0]}</span>
            </div>
          )}
        </div>

        {/* Error State */}
        {status === SearchStatus.ERROR && (
          <div className="rounded-xl bg-red-50 p-4 mb-8 border border-red-200 flex items-start animate-fade-in">
            <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
            <div className="ml-3">
              <h3 className="text-sm font-bold text-red-800">搜索出错</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
        )}

        {/* Data Grid / Table View */}
        {allBusinesses.length > 0 ? (
            <div className="animate-fade-in h-[calc(100vh-350px)] flex flex-col">
                <div className="flex justify-between items-center mb-5 px-1">
                    <div className="flex items-center gap-3 bg-white px-3 py-1.5 rounded-lg border border-gray-200 shadow-sm">
                        <Database className="w-4 h-4 text-brand-500" />
                        <span className="text-sm font-semibold text-gray-700">
                            {selectedIndices.size > 0 
                                ? `已选择 ${selectedIndices.size} 条线索` 
                                : '请选择线索进行操作'}
                        </span>
                    </div>
                    <div className="flex gap-3">
                        <button
                            onClick={handleShare}
                            className="inline-flex items-center px-4 py-2.5 border border-gray-200 shadow-sm text-sm font-medium rounded-xl text-gray-700 bg-white hover:bg-gray-50 hover:border-gray-300 transition-all"
                        >
                            <Share2 className="mr-2 h-4 w-4 text-gray-500" />
                            分享结果
                        </button>
                        <button
                            onClick={() => setShowEmailModal(true)}
                            disabled={selectedIndices.size === 0}
                            className="inline-flex items-center px-5 py-2.5 border border-transparent shadow-md shadow-gray-200 text-sm font-medium rounded-xl text-white bg-gray-900 hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none transition-all transform active:scale-95"
                        >
                            <Mail className="-ml-1 mr-2 h-4 w-4" />
                            邮件营销
                        </button>
                        <button
                            onClick={exportToCSV}
                            className="inline-flex items-center px-5 py-2.5 border border-gray-200 shadow-sm text-sm font-medium rounded-xl text-gray-700 bg-white hover:bg-brand-50 hover:text-brand-700 hover:border-brand-200 transition-all"
                        >
                            <Download className="-ml-1 mr-2 h-4 w-4 text-gray-500" />
                            导出 CSV
                        </button>
                    </div>
                </div>

                <div className="flex-1 min-h-0">
                    <BusinessTable 
                        businesses={allBusinesses} 
                        selectedIndices={selectedIndices}
                        onSelectionChange={setSelectedIndices}
                    />
                </div>
            </div>
        ) : (
             /* Empty State */
            status === SearchStatus.IDLE && (
                <div className="flex flex-col items-center justify-center py-20 bg-white/50 rounded-3xl border-2 border-dashed border-gray-200/80 hover:border-brand-200 hover:bg-white/80 transition-all cursor-default">
                    <div className="bg-gradient-to-br from-brand-50 to-brand-100 p-6 rounded-full mb-6 shadow-inner">
                        <Globe className="h-12 w-12 text-brand-500" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">准备好开发客户了吗？</h3>
                    <p className="mt-3 text-gray-500 max-w-md text-center leading-relaxed">
                        输入您的产品关键词，AI 将自动为您在全网搜寻精准的 B2B 潜在客户、联系人和联系方式。
                    </p>
                    <div className="mt-8 flex gap-3 text-xs text-gray-400 font-medium uppercase tracking-wider">
                        <span>• 智能去重</span>
                        <span>• 邮箱挖掘</span>
                        <span>• 社交媒体</span>
                    </div>
                </div>
            )
        )}

        {/* Email Campaign Modal */}
        {allBusinesses.length > 0 && (
            <EmailCampaignModal 
                isOpen={showEmailModal} 
                onClose={() => setShowEmailModal(false)}
                // Filter only selected businesses for the modal
                businesses={allBusinesses.filter((_, i) => selectedIndices.has(i))}
            />
        )}
      </main>
    </div>
  );
};

export default App;