import { LucideIcon, Globe, MapPin, Phone, Mail, MessageCircle, Link as LinkIcon, Facebook, Linkedin, Instagram } from 'lucide-react';

export const POPULAR_COUNTRIES = [
  "United States",
  "United Kingdom",
  "Canada",
  "Australia",
  "Germany",
  "France",
  "Italy",
  "Spain",
  "Netherlands",
  "United Arab Emirates",
  "Saudi Arabia",
  "Singapore",
  "Japan",
  "South Korea",
  "India",
  "Brazil",
  "Mexico",
  "South Africa",
  "Nigeria",
  "Vietnam",
  "Thailand",
  "Indonesia",
  "Malaysia",
  "Russia",
  "Turkey"
];

// Map generic social keys to Lucide icons
export const SOCIAL_ICONS: Record<string, LucideIcon> = {
  linkedin: Linkedin,
  facebook: Facebook,
  instagram: Instagram,
};