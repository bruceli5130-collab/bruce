import React from 'react';
import { GroundingChunk } from '../types';
import { Info } from 'lucide-react';

interface GroundingSourcesProps {
  chunks: GroundingChunk[];
}

const GroundingSources: React.FC<GroundingSourcesProps> = ({ chunks }) => {
  if (!chunks || chunks.length === 0) return null;

  // Deduplicate sources based on URI
  const uniqueChunks = chunks.reduce((acc, current) => {
    const x = acc.find(item => item.web?.uri === current.web?.uri);
    if (!x && current.web) {
      return acc.concat([current]);
    } else {
      return acc;
    }
  }, [] as GroundingChunk[]);

  return (
    <div className="mt-8 bg-gray-50 rounded-lg border border-gray-200 p-4">
      <div className="flex items-center gap-2 mb-3 text-gray-700">
        <Info className="w-4 h-4" />
        <h4 className="text-sm font-semibold">Sources verified by Google Search</h4>
      </div>
      <div className="flex flex-wrap gap-2">
        {uniqueChunks.map((chunk, index) => (
          chunk.web ? (
            <a
              key={index}
              href={chunk.web.uri}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-white border border-gray-300 text-gray-600 hover:bg-brand-50 hover:text-brand-700 hover:border-brand-200 transition-colors truncate max-w-[300px]"
            >
              {chunk.web.title || new URL(chunk.web.uri).hostname}
            </a>
          ) : null
        ))}
      </div>
    </div>
  );
};

export default GroundingSources;