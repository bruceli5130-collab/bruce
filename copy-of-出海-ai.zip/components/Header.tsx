import React from 'react';
import { Globe2, Share2 } from 'lucide-react';

const Header: React.FC = () => {
  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
        alert("链接已复制！\n您可以将此链接发送到手机或分享给同事。");
    }).catch(() => {
        alert("无法自动复制，请手动复制浏览器地址栏链接。");
    });
  };

  return (
    <header className="bg-white/80 backdrop-blur-md border-b border-brand-100 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-brand-600 to-brand-700 p-2 rounded-xl shadow-lg shadow-brand-500/30">
              <Globe2 className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 tracking-tight">外贸获客 AI</h1>
              <p className="text-[10px] text-brand-600 font-bold uppercase tracking-widest">Global Sourcing Engine</p>
            </div>
          </div>
          <nav className="flex items-center gap-4">
             <div className="hidden md:flex gap-6">
                <a href="#" className="text-sm font-medium text-gray-600 hover:text-brand-600 transition-colors">控制台</a>
                <a href="#" className="text-sm font-medium text-gray-600 hover:text-brand-600 transition-colors">我的线索</a>
             </div>
             <div className="h-5 w-px bg-gray-200 hidden md:block"></div>
             <button 
                onClick={handleShare}
                className="flex items-center gap-2 text-sm font-medium text-brand-600 hover:text-brand-700 bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-full transition-colors"
             >
                <Share2 className="w-4 h-4" />
                <span>分享</span>
             </button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;