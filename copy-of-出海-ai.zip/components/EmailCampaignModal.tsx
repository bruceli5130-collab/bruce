import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Mail, ChevronRight, CheckCircle2, FileText, AlertCircle, Send, Loader2, Users, Settings, Eye, Edit3, Play } from 'lucide-react';
import { BusinessProfile } from '../types';

interface EmailCampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
  businesses: BusinessProfile[];
}

type Step = 'setup' | 'templates' | 'recipients' | 'sending' | 'complete';
type Tab = 'discovery' | 'followup';
type Mode = 'edit' | 'preview';

interface EmailTemplate {
  subject: string;
  body: string;
}

const EmailCampaignModal: React.FC<EmailCampaignModalProps> = ({ isOpen, onClose, businesses }) => {
  const [step, setStep] = useState<Step>('setup');
  const [activeTab, setActiveTab] = useState<Tab>('discovery');
  const [mode, setMode] = useState<Mode>('edit');
  
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  
  const [discoveryEmail, setDiscoveryEmail] = useState<EmailTemplate>({ 
    subject: 'Partnership Opportunity: {Company} x GlobalLeads', 
    body: 'Hi {Name},\n\nI came across {Company} and was impressed by your work in the industry.\n\nWe help businesses like yours source high-quality products directly from manufacturers.\n\nWould you be open to a quick chat?\n\nBest,\n{Sender}' 
  });
  const [followUpEmail, setFollowUpEmail] = useState<EmailTemplate>({ 
    subject: 'Re: Partnership Opportunity', 
    body: 'Hi {Name},\n\nJust bumping this to the top of your inbox.\n\nLet me know if you have any questions.\n\nBest,\n{Sender}' 
  });

  const [selectedRecipients, setSelectedRecipients] = useState<Set<number>>(new Set());
  const [sendingProgress, setSendingProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const logEndRef = useRef<HTMLDivElement>(null);

  // Initialize valid recipients
  useEffect(() => {
    if (isOpen) {
        const validIndices = businesses
            .map((b, i) => (b.email && b.email !== 'N/A' ? i : -1))
            .filter(i => i !== -1);
        setSelectedRecipients(new Set(validIndices));
    }
  }, [isOpen, businesses]);

  // Auto-scroll logs
  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (activeTab === 'discovery') {
        setDiscoveryEmail(prev => ({ ...prev, body: text }));
      } else {
        setFollowUpEmail(prev => ({ ...prev, body: text }));
      }
    };
    reader.readAsText(file);
    // Reset input
    e.target.value = '';
  };

  const toggleRecipient = (index: number) => {
    const newSet = new Set(selectedRecipients);
    if (newSet.has(index)) {
      newSet.delete(index);
    } else {
      newSet.add(index);
    }
    setSelectedRecipients(newSet);
  };

  const startCampaign = async () => {
    setStep('sending');
    // Fix: cast index to number to avoid type error
    const recipientsList = Array.from(selectedRecipients).map((i) => businesses[i as number]);
    const total = recipientsList.length;
    
    setLogs(prev => [...prev, `[System] Initializing campaign for ${total} contacts...`]);

    for (let i = 0; i < total; i++) {
      const recipient = recipientsList[i];
      await new Promise(resolve => setTimeout(resolve, Math.random() * 500 + 300)); // Random delay
      
      setSendingProgress(((i + 1) / total) * 100);
      setLogs(prev => [...prev, `[Sent] Discovery email -> ${recipient.email} (${recipient.name})`]);
      
      if (i % 3 === 0) {
         await new Promise(resolve => setTimeout(resolve, 200)); // Occasional extra delay
      }
    }
    
    setLogs(prev => [...prev, `[System] Campaign finished successfully.`]);
    await new Promise(resolve => setTimeout(resolve, 800));
    setStep('complete');
  };

  const insertVariable = (variable: string) => {
    const textToInsert = `{${variable}}`;
    // This is a simplified insertion. In a real app, we'd track cursor position.
    if (activeTab === 'discovery') {
        setDiscoveryEmail(prev => ({ ...prev, body: prev.body + textToInsert }));
    } else {
        setFollowUpEmail(prev => ({ ...prev, body: prev.body + textToInsert }));
    }
  };

  const getPreviewText = (template: EmailTemplate) => {
    // FIX: Use Array.from to safely get first element instead of iterator and cast to number array
    const indices = Array.from(selectedRecipients) as number[];
    const previewIndex = indices.length > 0 ? indices[0] : 0;
    
    // Handle case where previewIndex might be out of bounds relative to full business list (though unlikely with current logic)
    const recipient = businesses[previewIndex] || { name: 'Example Client', description: 'Tech Corp', email: 'client@example.com' };
    
    let text = template.body;
    text = text.replace(/{Name}/g, recipient.name || 'Client');
    text = text.replace(/{Company}/g, recipient.name || 'Company'); // Using name as company proxy
    text = text.replace(/{Sender}/g, senderName || 'Your Name');
    
    return text;
  };

  const renderSidebar = () => (
    <div className="w-64 bg-gray-50 border-r border-gray-200 p-6 hidden md:flex flex-col justify-between">
       <div>
        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-6">设置步骤 (Steps)</h3>
        <nav className="space-y-2">
            {[
                { id: 'setup', label: '发件人设置', icon: Users },
                { id: 'templates', label: '邮件模板', icon: FileText },
                { id: 'recipients', label: '目标客户', icon: Settings },
                { id: 'sending', label: '开始发送', icon: Send },
            ].map((item) => (
                <div 
                    key={item.id}
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                        step === item.id 
                        ? 'bg-white text-brand-600 shadow-sm border border-gray-200' 
                        : 'text-gray-500'
                    }`}
                >
                    <item.icon className="w-4 h-4" />
                    {item.label}
                </div>
            ))}
        </nav>
       </div>
       
       <div className="p-4 bg-brand-50 rounded-xl border border-brand-100">
            <p className="text-xs text-brand-700 font-medium mb-1">Pro Tip</p>
            <p className="text-xs text-brand-600 leading-relaxed">
                个性化邮件能提高 300% 的回复率。请使用 {'{Name}'} 等变量。
            </p>
       </div>
    </div>
  );

  const renderSetup = () => (
    <div className="max-w-md mx-auto pt-8">
        <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900">发件人配置</h3>
            <p className="text-sm text-gray-500 mt-1">您的客户将看到这些信息</p>
        </div>
      <div className="space-y-6 bg-white p-8 rounded-2xl border border-gray-100 shadow-xl shadow-gray-100">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">发件人姓名 (Sender Name)</label>
          <input
            type="text"
            value={senderName}
            onChange={(e) => setSenderName(e.target.value)}
            placeholder="e.g. David Chen"
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">发件人邮箱 (Sender Email)</label>
          <input
            type="email"
            value={senderEmail}
            onChange={(e) => setSenderEmail(e.target.value)}
            placeholder="e.g. david@export.com"
            className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white"
          />
        </div>
      </div>
    </div>
  );

  const renderTemplates = () => {
    const currentTemplate = activeTab === 'discovery' ? discoveryEmail : followUpEmail;
    const setTemplate = activeTab === 'discovery' ? setDiscoveryEmail : setFollowUpEmail;

    return (
        <div className="h-full flex flex-col">
            <div className="flex items-center justify-between mb-6">
                <div className="flex p-1 bg-gray-100 rounded-lg">
                    <button 
                        onClick={() => setActiveTab('discovery')}
                        className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${activeTab === 'discovery' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        开发信 (First Email)
                    </button>
                    <button 
                        onClick={() => setActiveTab('followup')}
                        className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${activeTab === 'followup' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        跟进信 (Follow-up)
                    </button>
                </div>

                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setMode(mode === 'edit' ? 'preview' : 'edit')}
                        className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                        {mode === 'edit' ? <><Eye className="w-4 h-4" /> 预览</> : <><Edit3 className="w-4 h-4" /> 编辑</>}
                    </button>
                </div>
            </div>

            {mode === 'edit' ? (
                 <div className="flex-1 flex gap-6 min-h-0">
                    <div className="flex-1 flex flex-col gap-4">
                        <input
                            type="text"
                            placeholder="Subject Line"
                            value={currentTemplate.subject}
                            onChange={(e) => setTemplate(prev => ({ ...prev, subject: e.target.value }))}
                            className="w-full px-4 py-3 text-sm font-medium border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                        />
                        <div className="flex-1 relative">
                            <textarea
                                placeholder="在此撰写您的邮件内容..."
                                value={currentTemplate.body}
                                onChange={(e) => setTemplate(prev => ({ ...prev, body: e.target.value }))}
                                className="w-full h-full p-5 text-sm border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent resize-none font-mono leading-relaxed"
                            />
                            <button 
                                onClick={() => fileInputRef.current?.click()}
                                className="absolute bottom-4 right-4 p-2 bg-white border border-gray-200 rounded-lg shadow-sm hover:bg-gray-50 text-gray-600"
                                title="Upload Text File"
                            >
                                <Upload className="w-4 h-4" />
                            </button>
                            <input
                                type="file"
                                ref={fileInputRef}
                                className="hidden"
                                accept=".txt,.md"
                                onChange={handleFileUpload}
                            />
                        </div>
                    </div>

                    {/* Variables Sidebar */}
                    <div className="w-48 flex flex-col gap-3">
                        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">插入变量</span>
                        {['Name', 'Company', 'Sender'].map(v => (
                            <button 
                                key={v}
                                onClick={() => insertVariable(v)}
                                className="flex items-center justify-between px-3 py-2.5 text-xs font-medium text-gray-700 bg-gray-50 border border-gray-200 rounded-lg hover:bg-white hover:border-brand-300 hover:text-brand-600 transition-all text-left group"
                            >
                                <span>{'{'}{v}{'}'}</span>
                                <span className="opacity-0 group-hover:opacity-100 text-brand-500">+</span>
                            </button>
                        ))}
                        
                        <div className="mt-auto p-3 bg-blue-50 rounded-lg border border-blue-100">
                            <p className="text-[10px] text-blue-700 leading-tight">
                                支持上传 .txt 文件快速导入模板。
                            </p>
                        </div>
                    </div>
                 </div>
            ) : (
                <div className="flex-1 bg-gray-50 rounded-xl border border-gray-200 p-8 overflow-y-auto">
                    <div className="bg-white shadow-sm rounded-lg max-w-2xl mx-auto overflow-hidden border border-gray-100">
                        <div className="bg-gray-50/50 px-6 py-3 border-b border-gray-100 flex justify-between items-center">
                            <span className="text-xs font-medium text-gray-500">New Message</span>
                            <div className="flex gap-1.5">
                                <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div>
                                <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div>
                                <div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
                            </div>
                        </div>
                        <div className="p-8">
                            <div className="mb-6 pb-4 border-b border-gray-100">
                                <p className="text-sm text-gray-500 mb-2">To: <span className="text-gray-900 bg-gray-100 px-2 py-0.5 rounded text-xs">Client Email</span></p>
                                <p className="text-sm text-gray-500">Subject: <span className="text-gray-900 font-semibold">{currentTemplate.subject}</span></p>
                            </div>
                            <div className="prose prose-sm max-w-none text-gray-700 whitespace-pre-wrap leading-7">
                                {getPreviewText(currentTemplate)}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
  };

  const renderRecipients = () => (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <div>
            <h3 className="text-lg font-bold text-gray-900">目标客户列表</h3>
            <p className="text-sm text-gray-500">确认将收到邮件的客户</p>
        </div>
        <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-gray-700 bg-brand-50 border border-brand-100 px-3 py-1 rounded-full">
                已选中 {selectedRecipients.size} 位
            </span>
            <button 
                onClick={() => {
                    if (selectedRecipients.size === businesses.filter(b => b.email && b.email !== 'N/A').length) {
                        setSelectedRecipients(new Set());
                    } else {
                        const validIndices = businesses
                            .map((b, i) => (b.email && b.email !== 'N/A' ? i : -1))
                            .filter(i => i !== -1);
                        setSelectedRecipients(new Set(validIndices));
                    }
                }}
                className="text-sm text-brand-600 hover:text-brand-700 font-medium"
            >
                {selectedRecipients.size > 0 ? '取消全选' : '全选有效客户'}
            </button>
        </div>
      </div>

      <div className="flex-1 border border-gray-200 rounded-xl overflow-hidden bg-white flex flex-col shadow-sm">
        <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex text-xs font-bold text-gray-500 uppercase tracking-wider">
            <div className="w-12 text-center">选择</div>
            <div className="flex-1">公司名称</div>
            <div className="flex-1">邮箱地址</div>
            <div className="w-24 text-center">状态</div>
        </div>
        <div className="overflow-y-auto flex-1 custom-scrollbar">
            {businesses.map((business, index) => {
                const hasEmail = business.email && business.email !== 'N/A';
                const isSelected = selectedRecipients.has(index);
                return (
                    <div 
                        key={index} 
                        onClick={() => hasEmail && toggleRecipient(index)}
                        className={`flex items-center px-4 py-3 border-b border-gray-50 last:border-0 transition-colors cursor-pointer ${
                            !hasEmail ? 'bg-gray-50 opacity-50 cursor-not-allowed' : 'hover:bg-brand-50/30'
                        }`}
                    >
                        <div className="w-12 flex justify-center">
                            <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${
                                isSelected ? 'bg-brand-600 border-brand-600 shadow-sm' : 'border-gray-300 bg-white'
                            }`}>
                                {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                            </div>
                        </div>
                        <div className="flex-1 pr-4">
                            <p className={`text-sm font-medium ${hasEmail ? 'text-gray-900' : 'text-gray-500'}`}>{business.name}</p>
                        </div>
                        <div className="flex-1 pr-4">
                            <p className="text-sm text-gray-500 font-mono">{business.email || '-'}</p>
                        </div>
                        <div className="w-24 flex justify-center">
                            {hasEmail ? (
                                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-100">READY</span>
                            ) : (
                                <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-400 text-[10px] font-bold border border-gray-200">NO EMAIL</span>
                            )}
                        </div>
                    </div>
                )
            })}
        </div>
      </div>
    </div>
  );

  const renderSending = () => (
    <div className="h-full flex flex-col items-center justify-center max-w-2xl mx-auto w-full">
      <div className="w-full mb-8">
        <div className="flex justify-between text-sm font-medium text-gray-700 mb-2">
            <span>发送进度 (Sending Progress)</span>
            <span>{Math.round(sendingProgress)}%</span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
            <div 
                className="bg-brand-600 h-full rounded-full transition-all duration-300 ease-out relative"
                style={{ width: `${sendingProgress}%` }}
            >
                <div className="absolute inset-0 bg-white/20 animate-[shimmer_1s_infinite]" style={{ backgroundImage: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent)' }}></div>
            </div>
        </div>
      </div>

      <div className="w-full bg-gray-900 rounded-xl p-5 font-mono text-xs text-emerald-400 h-64 overflow-hidden flex flex-col shadow-2xl border border-gray-800">
        <div className="flex-1 overflow-y-auto space-y-1.5 custom-scrollbar">
            {logs.map((log, i) => (
                <div key={i} className="opacity-90 border-l-2 border-emerald-500/50 pl-2">{log}</div>
            ))}
            <div ref={logEndRef} />
        </div>
      </div>
      
      <p className="mt-6 text-gray-500 text-sm flex items-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin" />
        请保持窗口开启，系统正在处理队列...
      </p>
    </div>
  );

  const renderComplete = () => (
    <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto animate-fade-in">
      <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-8 shadow-lg shadow-emerald-100 animate-bounce-small">
        <CheckCircle2 className="w-12 h-12" />
      </div>
      <h3 className="text-3xl font-bold text-gray-900 mb-3">营销任务已启动</h3>
      <p className="text-gray-600 mb-10 leading-relaxed text-lg">
        成功为 <strong className="text-gray-900 bg-gray-100 px-2 py-0.5 rounded">{selectedRecipients.size} 家企业</strong> 创建了邮件任务。系统将在后台自动执行跟进逻辑。
      </p>
      <div className="flex gap-4 w-full">
        <button
            onClick={onClose}
            className="flex-1 px-6 py-4 bg-white border border-gray-200 text-gray-700 font-bold rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all"
        >
            返回列表
        </button>
        <button
            onClick={onClose}
            className="flex-1 px-6 py-4 bg-brand-600 text-white font-bold rounded-xl hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/30"
        >
            查看效果报表
        </button>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 py-6 sm:p-6">
      <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[90vh] flex overflow-hidden ring-1 ring-black/5 animate-fade-in">
        {/* Sidebar Navigation */}
        {step !== 'complete' && renderSidebar()}

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0">
            {/* Header */}
            <div className="px-8 py-5 border-b border-gray-100 flex justify-between items-center bg-white">
                <div>
                    <h2 className="text-xl font-bold text-gray-900 tracking-tight">邮件营销助手</h2>
                    <p className="text-sm text-gray-500">Automated Email Outreach</p>
                </div>
                <button 
                    onClick={onClose}
                    className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
                >
                    <X className="w-5 h-5" />
                </button>
            </div>

            {/* Step Content */}
            <div className="flex-1 overflow-y-auto p-8 bg-white relative">
                {step === 'setup' && renderSetup()}
                {step === 'templates' && renderTemplates()}
                {step === 'recipients' && renderRecipients()}
                {step === 'sending' && renderSending()}
                {step === 'complete' && renderComplete()}
            </div>

            {/* Footer Controls */}
            {step !== 'sending' && step !== 'complete' && (
                <div className="px-8 py-5 bg-white border-t border-gray-100 flex justify-between items-center">
                    <button
                        onClick={onClose}
                        className="px-6 py-2.5 text-sm font-medium text-gray-500 hover:text-gray-900 transition-colors"
                    >
                        取消
                    </button>
                    
                    <div className="flex gap-3">
                        {step !== 'setup' && (
                            <button
                                onClick={() => {
                                    if (step === 'templates') setStep('setup');
                                    if (step === 'recipients') setStep('templates');
                                }}
                                className="px-6 py-2.5 text-sm font-bold text-gray-600 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 hover:shadow-sm transition-all"
                            >
                                上一步
                            </button>
                        )}
                        
                        <button
                            onClick={() => {
                                if (step === 'setup') {
                                    if(senderName && senderEmail) setStep('templates');
                                } else if (step === 'templates') {
                                    if(discoveryEmail.body) setStep('recipients');
                                } else if (step === 'recipients') {
                                    startCampaign();
                                }
                            }}
                            disabled={
                                (step === 'setup' && (!senderName || !senderEmail)) ||
                                (step === 'templates' && (!discoveryEmail.body)) ||
                                (step === 'recipients' && selectedRecipients.size === 0)
                            }
                            className="flex items-center gap-2 px-8 py-2.5 bg-brand-600 text-white text-sm font-bold rounded-xl hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-brand-500/20 hover:shadow-brand-500/40 active:scale-95"
                        >
                            {step === 'recipients' ? (
                                <>
                                    <Send className="w-4 h-4" /> 立即发送
                                </>
                            ) : (
                                <>
                                    下一步 <ChevronRight className="w-4 h-4" />
                                </>
                            )}
                        </button>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default EmailCampaignModal;