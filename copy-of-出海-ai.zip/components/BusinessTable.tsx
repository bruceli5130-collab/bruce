import React from 'react';
import { BusinessProfile } from '../types';
import { Globe, Mail, Phone, MessageCircle, Linkedin, Facebook, Instagram, User, MapPin } from 'lucide-react';

interface BusinessTableProps {
  businesses: BusinessProfile[];
  onSelectionChange: (selectedIndices: Set<number>) => void;
  selectedIndices: Set<number>;
}

const BusinessTable: React.FC<BusinessTableProps> = ({ businesses, onSelectionChange, selectedIndices }) => {
  
  const toggleSelectAll = () => {
    if (selectedIndices.size === businesses.length) {
      onSelectionChange(new Set());
    } else {
      const all = new Set(businesses.map((_, i) => i));
      onSelectionChange(all);
    }
  };

  const toggleRow = (index: number) => {
    const newSet = new Set(selectedIndices);
    if (newSet.has(index)) {
      newSet.delete(index);
    } else {
      newSet.add(index);
    }
    onSelectionChange(newSet);
  };

  // Helper to safely extract hostname without crashing
  const getHostname = (urlStr: string) => {
    if (!urlStr) return '';
    try {
        // Ensure protocol exists to make URL constructor happy
        const urlWithProtocol = urlStr.startsWith('http') ? urlStr : `https://${urlStr}`;
        const urlObj = new URL(urlWithProtocol);
        return urlObj.hostname.replace('www.', '');
    } catch (e) {
        // Fallback: just return the string truncated if it's not a valid URL
        return urlStr.length > 20 ? urlStr.substring(0, 20) + '...' : urlStr;
    }
  };

  // Helper to ensure valid href
  const getHref = (urlStr: string) => {
      if (!urlStr) return '#';
      return urlStr.startsWith('http') ? urlStr : `https://${urlStr}`;
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden flex flex-col h-full">
      <div className="overflow-x-auto custom-scrollbar">
        <table className="min-w-full divide-y divide-gray-100">
          <thead>
            <tr className="bg-gray-50/80">
              <th scope="col" className="px-4 py-3 text-left w-10">
                <input
                  type="checkbox"
                  checked={businesses.length > 0 && selectedIndices.size === businesses.length}
                  onChange={toggleSelectAll}
                  className="h-4 w-4 text-brand-600 focus:ring-brand-500 border-gray-300 rounded cursor-pointer"
                />
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider min-w-[220px]">
                公司信息 (Company)
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider min-w-[160px]">
                联系人 (Contact)
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider min-w-[200px]">
                联系方式 (Details)
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider min-w-[140px]">
                社交媒体 (Social)
              </th>
              <th scope="col" className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                地区 (Location)
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-50">
            {businesses.map((business, index) => (
              <tr key={index} className={`hover:bg-brand-50/40 transition-colors group ${selectedIndices.has(index) ? 'bg-brand-50/60' : ''}`}>
                <td className="px-4 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedIndices.has(index)}
                    onChange={() => toggleRow(index)}
                    className="h-4 w-4 text-brand-600 focus:ring-brand-500 border-gray-300 rounded cursor-pointer"
                  />
                </td>
                <td className="px-4 py-4">
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-gray-900 mb-1 truncate max-w-[220px]" title={business.name}>
                      {business.name}
                    </span>
                    {business.website ? (
                      <a href={getHref(business.website)} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-brand-600 hover:text-brand-700 hover:underline w-fit">
                        <Globe className="w-3 h-3" /> {getHostname(business.website)}
                      </a>
                    ) : (
                        <span className="text-xs text-gray-400 flex items-center gap-1"><Globe className="w-3 h-3" /> 暂无网站</span>
                    )}
                    <p className="text-xs text-gray-500 mt-1.5 line-clamp-1 font-light" title={business.description}>{business.description}</p>
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <div className="bg-gray-100 p-1.5 rounded-full group-hover:bg-white transition-colors">
                        <User className="w-3 h-3 text-gray-500" />
                    </div>
                    <span className="text-sm text-gray-700 font-medium">
                        {business.contactPerson && business.contactPerson !== 'N/A' ? business.contactPerson : 'Unknown'}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="space-y-2">
                    {business.email && business.email !== 'N/A' && (
                      <div className="flex items-center gap-2 text-xs text-gray-700 group-hover:text-gray-900">
                        <Mail className="w-3 h-3 text-gray-400 group-hover:text-brand-500" />
                        <span className="truncate max-w-[160px] select-all cursor-copy hover:text-brand-600">{business.email}</span>
                      </div>
                    )}
                    {business.whatsapp && business.whatsapp !== 'N/A' && (
                       <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-100 w-fit shadow-sm">
                         <MessageCircle className="w-3 h-3" />
                         <span className="font-bold select-all cursor-copy">{business.whatsapp}</span>
                       </div>
                    )}
                    {business.phone && business.phone !== 'N/A' && !business.whatsapp && (
                         <div className="flex items-center gap-2 text-xs text-gray-600">
                            <Phone className="w-3 h-3 text-gray-400" />
                            <span className="select-all cursor-copy">{business.phone}</span>
                         </div>
                    )}
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex gap-2">
                        {business.socialMedia?.linkedin && (
                            <a href={getHref(business.socialMedia.linkedin)} target="_blank" className="p-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors"><Linkedin className="w-3.5 h-3.5" /></a>
                        )}
                        {business.socialMedia?.facebook && (
                            <a href={getHref(business.socialMedia.facebook)} target="_blank" className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors"><Facebook className="w-3.5 h-3.5" /></a>
                        )}
                        {business.socialMedia?.instagram && (
                            <a href={getHref(business.socialMedia.instagram)} target="_blank" className="p-1.5 rounded-lg bg-pink-50 text-pink-600 hover:bg-pink-100 transition-colors"><Instagram className="w-3.5 h-3.5" /></a>
                        )}
                        {(!business.socialMedia?.linkedin && !business.socialMedia?.facebook && !business.socialMedia?.instagram) && (
                            <span className="text-xs text-gray-300">-</span>
                        )}
                    </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-gray-50 w-fit px-2 py-1 rounded">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        <span className="truncate max-w-[120px]" title={business.address}>{business.address || 'N/A'}</span>
                    </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default BusinessTable;