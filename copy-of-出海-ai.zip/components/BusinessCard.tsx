import React from 'react';
import { BusinessProfile } from '../types';
import { MapPin, Globe, Mail, Phone, MessageCircle, ExternalLink, Building2, Share2 } from 'lucide-react';
import { SOCIAL_ICONS } from '../constants';

interface BusinessCardProps {
  business: BusinessProfile;
}

const BusinessCard: React.FC<BusinessCardProps> = ({ business }) => {
  // Helper to check if we have any valid social links
  const hasSocialLinks = business.socialMedia && Object.values(business.socialMedia).some(url => !!url);

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden flex flex-col h-full">
      <div className="p-5 flex-1">
        <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-2">
            <div className="bg-brand-50 p-2 rounded-md">
                <Building2 className="w-5 h-5 text-brand-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 line-clamp-1" title={business.name}>
              {business.name}
            </h3>
          </div>
        </div>

        <p className="text-sm text-gray-600 mb-4 line-clamp-2 h-10">
          {business.description || "No description available."}
        </p>

        <div className="space-y-3">
          {/* Address */}
          <div className="flex items-start gap-3 text-sm text-gray-600">
            <MapPin className="w-4 h-4 mt-0.5 text-gray-400 shrink-0" />
            <span className="break-words">{business.address || "Location not specified"}</span>
          </div>

          {/* Website */}
          {business.website && (
            <div className="flex items-center gap-3 text-sm">
              <Globe className="w-4 h-4 text-gray-400 shrink-0" />
              <a 
                href={business.website} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-brand-600 hover:text-brand-700 hover:underline flex items-center gap-1 truncate max-w-[200px]"
              >
                Visit Website <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-100 space-y-2">
             {/* Email */}
             <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <span className="text-xs font-medium text-gray-700 uppercase">Email</span>
                </div>
                <span className={`text-sm ${business.email && business.email !== 'N/A' ? 'text-gray-900 select-all' : 'text-gray-400'}`}>
                    {business.email || 'N/A'}
                </span>
            </div>

            {/* Phone */}
            <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <span className="text-xs font-medium text-gray-700 uppercase">Phone</span>
                </div>
                {business.phone && business.phone !== 'N/A' ? (
                    <a 
                        href={`tel:${business.phone}`} 
                        className="text-sm text-gray-900 hover:text-brand-600 font-medium hover:underline select-all"
                    >
                        {business.phone}
                    </a>
                ) : (
                    <span className="text-sm text-gray-400">
                        {business.phone || 'N/A'}
                    </span>
                )}
            </div>

            {/* WhatsApp - Highlighted */}
            {business.whatsapp && business.whatsapp !== 'N/A' && (
                <div className="flex items-center justify-between p-2 bg-green-50 border border-green-100 rounded-lg">
                    <div className="flex items-center gap-2">
                        <MessageCircle className="w-4 h-4 text-green-600" />
                        <span className="text-xs font-bold text-green-700 uppercase">WhatsApp</span>
                    </div>
                    <span className="text-sm font-bold text-green-800 select-all">
                        {business.whatsapp}
                    </span>
                </div>
            )}
        </div>

        {/* Social Media Links */}
        {hasSocialLinks && (
           <div className="mt-4 pt-3 border-t border-gray-100">
             <p className="text-xs font-medium text-gray-500 mb-2">Social Profiles</p>
             <div className="flex gap-2">
               {business.socialMedia && Object.entries(business.socialMedia).map(([platform, url]) => {
                 if (!url) return null;
                 const Icon = SOCIAL_ICONS[platform.toLowerCase()] || Share2;
                 return (
                   <a 
                     key={platform} 
                     href={url} 
                     target="_blank" 
                     rel="noopener noreferrer"
                     className="p-2 rounded-full bg-gray-50 text-gray-600 hover:bg-brand-50 hover:text-brand-600 transition-colors border border-gray-100 hover:border-brand-200"
                     title={platform.charAt(0).toUpperCase() + platform.slice(1)}
                   >
                     <Icon className="w-4 h-4" />
                   </a>
                 );
               })}
             </div>
           </div>
        )}
      </div>
    </div>
  );
};

export default BusinessCard;