import { GoogleGenAI } from "@google/genai";
import { BusinessProfile, GemeniResponseData, SearchResult } from '../types';

const cleanJsonString = (text: string): string => {
  // Remove markdown code blocks if present
  let cleaned = text.replace(/```json\n?/g, '').replace(/```/g, '');
  return cleaned.trim();
};

// We add a 'context' parameter to help the AI find NEW businesses in subsequent calls
export const searchBusinesses = async (
  keyword: string, 
  country: string, 
  existingNames: string[] = [],
  searchType: string = 'general' // 'manufacturers', 'distributors', 'wholesalers' to vary results
): Promise<GemeniResponseData> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey });

  // We limit the exclusion list to the last 30 to save tokens but maintain context
  const exclusionList = existingNames.slice(-30).join(", ");

  const prompt = `
    Act as an expert Foreign Trade B2B Sourcing Agent.
    
    Task: Find 10-15 NEW, REAL, and HIGH-QUALITY Business Leads for "${keyword}" located in "${country}".
    Search specifically for this role/type: ${searchType}.
    
    STRICT RULES:
    1. **Format**: Return ONLY valid JSON. Do not add markdown formatting outside the JSON.
    2. **Exclusion**: DO NOT include these companies: ${exclusionList}.
    3. **Contacts**: You MUST prioritize companies where you can find a **WhatsApp** number, **Email** (info@ or sales@), or **Social Media** links.
    4. **URLs**: Website URLs must be valid standard URLs (e.g. www.example.com).
    5. **Language**: Return the business descriptions in English (standard for international trade).

    Required JSON Structure:
    {
      "summary": "One sentence summary of findings.",
      "businesses": [
        {
          "name": "Business Name (Official)",
          "description": "Professional summary (max 15 words)",
          "address": "City, State/Province",
          "website": "www.example.com",
          "contactPerson": "Name (Sales Manager/Owner) or 'N/A'",
          "email": "Valid Email or 'N/A'",
          "phone": "Phone with country code or 'N/A'",
          "whatsapp": "WhatsApp with country code or 'N/A'",
          "socialMedia": {
            "linkedin": "Full URL or null",
            "facebook": "Full URL or null",
            "instagram": "Full URL or null"
          }
        }
      ]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        // IMPORTANT: Do not set responseMimeType when using googleSearch
      },
    });

    const rawText = response.text || "";
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    let parsedResult: SearchResult | null = null;

    try {
      // Attempt to find JSON pattern if extra text exists
      const jsonMatch = rawText.match(/```json([\s\S]*?)```/) || rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const jsonString = cleanJsonString(jsonMatch[0] || jsonMatch.input || rawText);
        parsedResult = JSON.parse(jsonString) as SearchResult;
      } else if (rawText.trim().startsWith('{')) {
        // Direct JSON parse if no markdown code block
        parsedResult = JSON.parse(cleanJsonString(rawText)) as SearchResult;
      }
    } catch (e) {
      console.error("JSON Parse Error:", e);
      console.log("Raw Text:", rawText);
    }

    return {
      result: parsedResult,
      rawText: rawText,
      groundingChunks: groundingChunks
    };

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};